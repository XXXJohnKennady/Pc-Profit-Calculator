
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.1.3/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs } from "https://www.gstatic.com/firebasejs/9.1.3/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBe8TI9DO04EOhriFxU27tOMdGeIF4zzzY",
    authDomain: "pc-profit-calculator-52b5d.firebaseapp.com",
    projectId: "pc-profit-calculator-52b5d",
    storageBucket: "pc-profit-calculator-52b5d.appspot.com",
    messagingSenderId: "32362015246",
    appId: "1:32362015246:web:90027c8502268bb29dea5f",
    measurementId: "G-7F58FWEED5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Reference to form and list container
const pcForm = document.getElementById('pcForm');
const pcList = document.getElementById('pcList');

// Add PC Build to Firestore
pcForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const pcName = document.getElementById('pcName').value;
    const costPrice = parseFloat(document.getElementById('costPrice').value);
    const salePrice = parseFloat(document.getElementById('salePrice').value);
    const netProfit = salePrice - costPrice;
    
    try {
        await addDoc(collection(db, "pcBuilds"), {
            pcName,
            costPrice,
            salePrice,
            netProfit
        });
        loadPCBuilds();
        pcForm.reset();
    } catch (e) {
        console.error("Error adding document: ", e);
    }
});

// Load PC Builds from Firestore
async function loadPCBuilds() {
    pcList.innerHTML = '';
    const querySnapshot = await getDocs(collection(db, "pcBuilds"));
    querySnapshot.forEach((doc) => {
        const data = doc.data();
        pcList.innerHTML += `<div>
            <h3>${data.pcName}</h3>
            <p>Cost Price: $${data.costPrice}</p>
            <p>Sale Price: $${data.salePrice}</p>
            <p>Net Profit: $${data.netProfit}</p>
        </div><hr>`;
    });
}

// Initial load
loadPCBuilds();
