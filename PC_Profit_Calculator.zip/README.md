
# PC Profit Calculator

A simple web app to manage PC builds, add cost, sale price, and calculate net profit.

## Setup Instructions
1. Clone this repository.
2. Install Firebase CLI and initialize Firebase Hosting.
3. Deploy to Firebase using `firebase deploy`.

## Firebase
Ensure Firebase is properly set up with Firestore for storing PC builds.

## Features
- Add PC builds with cost and sale price.
- View list of PC builds with calculated net profit.
